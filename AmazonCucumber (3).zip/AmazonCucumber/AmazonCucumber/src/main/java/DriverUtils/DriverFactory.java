package DriverUtils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class DriverFactory {

	    
	    public static WebDriver driver;
	    
	    private static boolean initialized = false;
	    public WebDriver init_Driver(String browser)
		{
	    	 if (!initialized) {
			if(browser.equals("chrome"))
			{
				 System.setProperty("webdriver.chrome.driver", "C:\\Users\\poojami\\eclipse-workspace\\chromedriver.exe");
			        driver = new ChromeDriver();  
			        initialized = true;
			}
	    	 }
			return driver; 
	
	        
	       
	    }
	    
	    public static WebDriver getDriver() {
	        return driver;
	    }
	    
	}

