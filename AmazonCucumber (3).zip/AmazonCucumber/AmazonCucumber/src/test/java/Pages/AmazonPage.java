package Pages;

import java.awt.AWTException;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.testng.Assert;

import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;



public class AmazonPage {
	WebDriver driver;
	public static String Cost;
	public static String rating;
	public static String review;
	public AmazonPage (WebDriver driver) {
		this.driver=driver;

	}
	By Mobldrpdwn=By.xpath("//*[@id='nav-xshop']/a[5]");	
	By menuLinks=By.xpath("//div[@id='nav-subnav']/a");
	By Brand=By.xpath("//a[contains(text(),'Dell')]");
	By Min=By.xpath("//*[@id='low-price']");
	By Max=By.xpath("//*[@id='high-price']");
	By goBtn=By.xpath("//span/input[@class='a-button-input']");
	By searchTab=By.xpath("//*[@id='twotabsearchtextbox']");
	By searchBtn=By.xpath("//*[@id='nav-search-submit-button']");
	By firstElement=By.xpath("(//div[1]/h2/a/span)[1]");
	By prodCost=By.xpath("//span[@class='a-price aok-align-center reinventPricePriceToPayMargin priceToPay']" 
			+ "//span[@class='a-price-whole']");
	By delLocation=By.xpath("//*[@id='contextualIngressPtLabel_deliveryShortLine']");
	By delPin=By.xpath("//*[@id='GLUXZipUpdateInput']");
	By ratingTxt=By.xpath("//span[@data-hook='rating-out-of-text']");
	By addToCart=By.xpath("//*[@id='add-to-cart-button']");
	By valCart=By.xpath("(//h4[contains(text(),'Added to Cart')])[2]");
	By reviewData=By.xpath("(//div[@class='a-expander-content reviewText review-text-content a-expander-partial-collapse-content']/span)[1]");



	public void LaunchApp(String url) 
	{


		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));


	}

	public void sleep(int num) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(num));
	}
	public void mouseHover(){
		Actions act= new Actions(driver);

		act.moveToElement(driver.findElement(By.xpath("//*[@id='nav-xshop']/a[5]"))).click().build().perform();
		sleep(3);

	}




	public void PrintMenu() {

		List<WebElement> menulist=driver.findElements(menuLinks);
		System.out.println("Menu list size is:"+ menulist.size());
		System.out.println("List items are:");

		for(WebElement ele: menulist) {

			System.out.println(ele.getText());
		}

	}

	public void LaptopBrandSelection(){
		Actions act= new Actions(driver);

		act.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Laptops & Accessories')]"))).build().perform();
		sleep(3);

		driver.findElement(Brand).click();
		sleep(5);

	}

	public void prizeAdjust(){
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.xpath("//*[@id='low-price']"));
		js.executeScript("arguments[0].scrollIntoView();", ele);
		sleep(4);

		driver.findElement(Min).sendKeys("40000");
		sleep(2);
		driver.findElement(Max).sendKeys("100000");
		sleep(1);
		driver.findElement(goBtn).click();
	}

	public void searchLaptop(){
		driver.findElement(searchTab).sendKeys("Gaming Laptop");
		sleep(1);
		driver.findElement(searchBtn).click();
		sleep(4);
		driver.findElement(firstElement).click();
		sleep(3);


	}



	public void verifyProdCost(Integer int1){
		try {
			ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
			driver.switchTo().window(tab.get(1));

			Cost=driver.findElement(prodCost).getText();
			Cost=Cost.replaceAll(",", "");
			System.out.println(Cost);

			int i=Integer.parseInt(Cost);  

			if(i>0) {
				Assert.assertTrue(i>int1);
				System.out.println("Product cost is greater than zero");
			}
		}catch (NumberFormatException nfe) {
			// Handle the condition when str is not a number.
		}

	}

	public void selectDeliverylocation() throws AWTException{
		driver.findElement(delLocation).click();
		sleep(2);
		driver.findElement(delPin).sendKeys("560035");
		driver.findElement(By.xpath("//span[@id='GLUXZipUpdate']")).click();
	}


	public void verifyRating() throws AWTException, IOException{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.xpath("//span[@data-hook='rating-out-of-text']"));
		js.executeScript("arguments[0].scrollIntoView();", ele);
		sleep(4);

		rating=driver.findElement(ratingTxt).getText();
		System.out.println(rating);

		review=driver.findElement(reviewData).getText();
		System.out.println(review);
		writeData(review);


	}

	public void add_ProductToCart() throws AWTException{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.xpath("//*[@id='add-to-cart-button']"));
		js.executeScript("arguments[0].scrollIntoView();", ele);
		sleep(4);
		driver.findElement(addToCart).click();
		sleep(6);
		if(driver.findElement(valCart).isDisplayed()) {
			System.out.println("product added to cart successfully");
		}
		else {
			System.out.println("product added to cart is not displayed");
		}
	}



	public void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
		//Convert web driver object to TakeScreenshot
		//Take Screen shots

		File source=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest= new File ("C:\\Users\\poojami\\eclipse-workspace\\AmazonCucumber\\src\\test\\resources\\ActualScreen\\Img.png");

		FileUtils.copyFile(source, dest);
	}

	public void CaptureScreen() throws IOException {
		//For Expected Screen shots
		BufferedImage ExpImage= ImageIO.read(new File("C:\\Users\\poojami\\eclipse-workspace\\AmazonCucumber\\src\\test\\resources\\ExpectedScreen\\Img1.png"));
		File dest= new File ("C:\\Users\\poojami\\eclipse-workspace\\AmazonCucumber\\src\\test\\resources\\ActualScreen\\Img.png");
		BufferedImage actualImage= ImageIO.read(dest);

		//Comparison of exp and act screen shots

		ImageDiffer diffImg= new ImageDiffer();
		ImageDiff difference=diffImg.makeDiff(ExpImage, actualImage);

		if(difference.hasDiff()==true) {
			System.out.println("Act and exp images are not same");

			//Assert.fail("Screen shots are not matching");
		}
		else {
			Assert.assertEquals(ExpImage, actualImage);
		}

	}

	public void closeBr() {

		driver.quit();
	}

	public void writeData(String result) {
		String excelFilePath ="C:\\Users\\poojami\\eclipse-workspace\\AmazonCucumber\\target\\TestData.xlsx";
		File file=new File(excelFilePath);
		Boolean Flag=false;
		try {
			FileInputStream inputStream = new FileInputStream(file);
			XSSFWorkbook wb=new XSSFWorkbook(inputStream);
			XSSFSheet sheet=wb.getSheet("Review_Data");
			XSSFRow row = sheet.createRow(0);
			int cellid=0;
			XSSFCell cell1 = row.createCell(cellid);
			cell1.setCellValue("Review");
			XSSFCell cell2 = row.createCell(cellid + 1);
			cell2.setCellValue(result);
			Flag=true;

			inputStream.close();
			FileOutputStream outputStream = new FileOutputStream(file);
			if(Flag==true) {
				wb.write(outputStream);
				System.out.println("File Written Successfully");
			}
			else {
				System.out.println("File not Written");
			}
			outputStream.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}


}
