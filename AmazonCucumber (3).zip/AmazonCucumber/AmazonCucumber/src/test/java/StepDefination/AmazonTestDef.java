package StepDefination;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;


import Pages.AmazonPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AmazonTestDef {
	public WebDriver driver=DriverUtils.DriverFactory.getDriver();
	AmazonPage AP=new AmazonPage(driver);
	
	@Given("user is on Amazon home page {string}")
	public void user_is_on_amazon_home_page(String string) {
		
		AP.LaunchApp(string);
	}

	@When("I click on Menu Mobiles")
	public void i_click_on_menu_mobiles() {
		
		AP.mouseHover();
		System.out.println("Fail");
	}

	@When("I am able to read and print all menu items,compare actual and expected screenshot")
	public void i_am_able_to_read_and_print_all_menu_items_compare_actual_and_expected_screenshot() throws Exception {
	
		AP.PrintMenu();
		AP.takeSnapShot(driver, null);
		AP.CaptureScreen();
	}

	@When("I am able to Hover on Laptops & Accessories,click on the “Dell” link Shop by brand")
	public void i_am_able_to_hover_on_laptops_accessories_click_on_the_dell_link_shop_by_brand() {
		
		AP.LaptopBrandSelection();
	}

	@When("I am able to Change the PRICE: Min and Max, Click on the Go button")
	public void i_am_able_to_change_the_price_min_and_max_click_on_the_go_button() {
		
		AP.prizeAdjust();
	}

	@When("I am able to Search for “Gaming Laptop” in the search bar,Click on the First Gaming laptop displayed on the screen")
	public void i_am_able_to_search_for_gaming_laptop_in_the_search_bar_click_on_the_first_gaming_laptop_displayed_on_the_screen() {
		
	AP.searchLaptop();
	}

	@Then("Verify that the product amount is greater than or equal to {int}")
	public void verify_that_the_product_amount_is_greater_than_or_equal_to(Integer int1) {
		
		AP.verifyProdCost(int1);
	}

	@Then("Click on “Select Delivery location” and Enter the Indian pin code Click on Apply")
	public void click_on_select_delivery_location_and_enter_the_indian_pin_code_click_on_apply() throws AWTException {
		// Write code here that turns the phrase above into concrete actions
		AP.selectDeliverylocation();
	}

	@Then("Scroll down and capture the rating,Read the customer review")
	public void scroll_down_and_capture_the_rating_read_the_customer_review() throws AWTException, IOException {
	    
	    AP.verifyRating();
	}

	@Then("Scroll up and click on “Add to Cart, Verify if the message “Added to Cart” is displayed")
	public void scroll_up_and_click_on_add_to_cart_verify_if_the_message_added_to_cart_is_displayed() throws AWTException {
		
		AP.add_ProductToCart();
	}

}
